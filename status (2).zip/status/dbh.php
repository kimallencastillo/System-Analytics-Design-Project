<?php

$server = "localhost";
$username = "root";
$password = "";
$dbname = "saddb";

$conn = mysqli_connect($server, $username, $password, $dbname);