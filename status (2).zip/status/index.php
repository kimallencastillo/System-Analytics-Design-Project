<?php
    include 'header.php';
?>



<h2>Applications</h2>


    <?php
        $sql = "SELECT * FROM files";
        $result = mysqli_query($conn, $sql);
        $queryResults = mysqli_num_rows($result);
        echo "<table class='table table-bordered table-hover' >";
			
				//Table header
				echo "<th>"; echo "Applicant ID";	echo "</th>";
				echo "<th>"; echo "Filename";  echo "</th>";
				echo "<th>"; echo "File";  echo "</th>";
                echo "<th>"; echo "Status";  echo "</th>";
			echo "</tr>";	

        if($queryResults > 0) {
            while($row = mysqli_fetch_assoc($result)) {
                echo "<table class='table table-bordered table-hover' >";
			
            echo "<td>"; echo $row['id']; echo "</td>";
            echo "<td>"; echo $row['filename']; echo "</td>";
            echo "<td>"; echo $row['file']; echo "</td>";
            echo "<td>"; echo $row['status']; echo "</td>";
			echo "</tr>";	

		echo "</table>";
            }
        }
    ?>


</body>
</html>